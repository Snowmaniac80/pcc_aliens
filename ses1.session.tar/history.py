# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Mon Jan 25 16:07:43 2016)---
runfile('C:/Users/pilgrim/Documents/Python_Workspace/untitled0.py', wdir='C:/Users/pilgrim/Documents/Python_Workspace')

##---(Mon Feb  1 09:56:36 2016)---
runfile('C:/Users/pilgrim/Documents/Python_Workspace/ai.py', wdir='C:/Users/pilgrim/Documents/Python_Workspace')
runfile('C:/Users/pilgrim/Documents/Python_Workspace/ai.py', wdir='C:/Users/pilgrim/Documents/Python_Workspace')
help(sys)
help()
runfile('C:/Users/pilgrim/Documents/Python_Workspace/ai.py', wdir='C:/Users/pilgrim/Documents/Python_Workspace')