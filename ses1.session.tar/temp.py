# -*- coding: utf-8 -*-
import sys

"""
Spyder Editor

This is a temporary script file.
"""

